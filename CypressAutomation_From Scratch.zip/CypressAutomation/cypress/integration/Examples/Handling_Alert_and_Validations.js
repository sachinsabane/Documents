///<reference types="cypress"/>
describe('Handle Alert', function()
{
it('Handling Alert and getting the text with windows events', function()
{
    cy.visit("https://rahulshettyacademy.com/AutomationPractice/")
    cy.get('#alertbtn').click()
    cy.on('window:alert',(stringAlert)=> 
    {
        expect(stringAlert).to.equal('Hello , share this practice page and share your knowledge') 
    })

    cy.get('#confirmbtn').click()
    cy.on('window:confirm',(Stalrlt)=>
    {
        expect(Stalrlt).to.equal('Hello , Are you sure you want to confirm?')
    })
    cy.get('.cen-align #opentab').invoke('removeAttr','target').click();
    
})

    




})
