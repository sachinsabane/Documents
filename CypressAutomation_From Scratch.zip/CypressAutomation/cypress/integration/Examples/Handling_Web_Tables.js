///<reference types="cypress"/>
describe('Handling webTables and iterating to get the child of the respective element in dom', function()
{
it('Handling webTables and iterating to get the child', function()
{
    cy.visit("https://rahulshettyacademy.com/AutomationPractice/")
    cy.get('#product td:nth-child(2)').each(($e1,index,list)=>{
        const CourseText=$e1.text()
        if(CourseText.includes('Python'))
        {
            cy.get('#product td:nth-child(2)').eq(index).next().then(function(Productprice)
            {
                const price= Productprice.text()
                expect(price).to.equal('25')
            })
        }

    })
   
    
})

    




})
