///<reference types="cypress"/>
describe('Checkbox Practise', function()
{
it('example for various check box scenarios', function()
{
    cy.visit("https://rahulshettyacademy.com/AutomationPractice/")
    cy.wait(2000)
    //cy.get('input#checkBoxOption1').check().should('be.checked').and('have.value','option1')
    cy.get('.right-align').find('input[type="checkbox"]').check(['option1','option3'])

    //code for Static Dropdown//
    cy.get('#dropdown-class-example').select('option3').should('have.value','option3')

    //code for Dynamic Dropdown//
    cy.get('input#autocomplete').type('Can')
    cy.get('.ui-menu-item div').each(($e1,index,$list)=>
    {
        if($e1.text()==="Canada")
        {
            cy.wrap($e1).click()
        }
    })
    cy.get('#displayed-text').should('be.visible')
        cy.get('#hide-textbox').click()
        cy.get('#displayed-text').should('not.be.visible')
        cy.get('#show-textbox').click()
        cy.get('#displayed-text').should('be.visible')

    })
})