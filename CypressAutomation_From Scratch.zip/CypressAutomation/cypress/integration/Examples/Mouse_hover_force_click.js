///<reference types="cypress"/>
describe('Hovering over a particular elment and also force click on hidden elements', function()
{
it('Hovering over a particular elment', function()
{
    cy.visit("https://rahulshettyacademy.com/AutomationPractice/")
    cy.get('div .mouse-hover-content').invoke('show')

    /*cy.contains('Top').click();*/
    cy.contains('Top').click({force: true})
    cy.url().should('include','top')
   /* for force clicking on hidden element, commenting the 8th and 9th line to remove mouse hover and adding one more line of code */
    
   
    
})

    




})
