///<reference types="cypress"/>
describe('My first Testcase', function()
{
it('My first test case', function()
{
    cy.visit("https://rahulshettyacademy.com/seleniumPractise/#/")
    cy.get('input.search-keyword').type('ca')
    cy.wait(5000)
    cy.get('.product:visible').should('have.length',4)
    cy.get('div.products').as('parentProduct')
    cy.get('@parentProduct').find('.product').eq(2).contains('ADD TO CART').click()
    cy.get('@parentProduct').find('.product').each(($e1,index,$list)=>{ //iteration in cypress
        const prdoName=$e1.find('h4.product-name').text() 
        //in 12th line we are getting the text of the product and storing in a cosntant
        if(prdoName.includes('Cashews')) // conditon we are provding (include is a keyword in js to get the text from a sentance just like contains)
        {
            cy.wrap($e1).contains('ADD TO CART').click() //if the text from the itration matched with the if statement it will click on the add to cart button
        }

    })
    cy.get('div.brand.greenLogo').should('have.text','GREENKART')
    cy.get('div.brand.greenLogo').then(function(logoText)
    {
        cy.log(logoText.text())
    })

})
})