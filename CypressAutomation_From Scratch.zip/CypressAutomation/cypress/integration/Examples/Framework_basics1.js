///<reference types="cypress"/>
///<reference types="cypress-iframe"/>
import 'cypress-iframe'
import homepage from '../Page_Object_Model/homepage'
import ShopPage from '../Page_Object_Model/ShopPage'
import checkout_page from '../Page_Object_Model/checkout_page'
describe('Framework_Learning_1', function()
{
    before(function(){
        cy.fixture('example').then(function(dataSheet)
        {
            this.dataSheet=dataSheet
        })
    })
it('Framework_Learning_1', function()
{
    const homePage= new homepage()
    const shoppage=new ShopPage()
    const checkout_Page= new checkout_page()
    cy.visit('https://www.rahulshettyacademy.com/angularpractice/')
    homePage.getEditBox().type(this.dataSheet.name)
    homePage.getGender().select(this.dataSheet.gender)
    homePage.getTwoWayBinding().should('have.value',this.dataSheet.name)
    homePage.getcheckBox().should('be.disabled')
    homePage.getEditBox().should('have.attr','minlength','2')
    homePage.getShoppage().click()
    Cypress.config('defaultCommandTimeout',8000)
    
    this.dataSheet.productName.forEach(function(product)
    {
        cy.SelectProduct(product)
    })
    shoppage.getCheckoutButton().click()
    checkout_Page.getcheckoutButtonText().click()
    checkout_Page.getDeliveryLocationname().type('India')
    checkout_Page.getdeliverylocationName().click()
    checkout_Page.getselectCheckbox().click({force: true})
    })
    
    
})


    




