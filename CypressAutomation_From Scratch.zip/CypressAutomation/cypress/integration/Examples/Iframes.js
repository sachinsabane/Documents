///<reference types="cypress"/>
///<reference types="cypress-iframe"/>
import 'cypress-iframe'
describe('Handling iframes in dom', function()
{
it('Handlingframes', function()
{
    cy.visit("https://rahulshettyacademy.com/AutomationPractice/")
    cy.frameLoaded('#courses-iframe')
    // whenever the frame is loaded we need to pitch in to that frame and we need to use the find locator to get the css
    cy.iframe().find('a[href="mentorship"]').eq(0).click()
    
    
    })
})

    




