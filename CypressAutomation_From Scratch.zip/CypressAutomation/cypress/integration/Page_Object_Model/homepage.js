class homepage
{
getEditBox()
{
return cy.get('div input[name="name"]:nth-child(2)')
}
getGender()
{
    return cy.get('select')
}
getTwoWayBinding()
{
    return cy.get('div input[name="name"]:nth-child(1)')
}
getcheckBox()
{
    return cy.get('#inlineRadio3')
}
getShoppage()
{
    return  cy.get(':nth-child(2) > .nav-link')
}

}
export default homepage;