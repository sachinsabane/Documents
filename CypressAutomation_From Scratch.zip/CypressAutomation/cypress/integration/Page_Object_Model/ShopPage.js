class ShopPage
{
getCheckoutButton()
{
    return cy.get('.nav-link.btn.btn-primary')
}
}
export default ShopPage