class checkout_page
{
    getcheckoutButtonText()
    {
        return cy.get('button.btn.btn-success')
    }

    getDeliveryLocationname()
    {
        return cy.get('#country')
    }
    
    getdeliverylocationName()
    {
        return cy.get('div.suggestions ul li a')
    }

    getselectCheckbox()
    {
        return cy.get('input[type="checkbox"]')
    }
}
export default checkout_page